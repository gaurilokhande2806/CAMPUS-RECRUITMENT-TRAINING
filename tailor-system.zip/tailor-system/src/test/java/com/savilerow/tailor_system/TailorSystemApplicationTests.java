package com.savilerow.tailor_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TailorSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
